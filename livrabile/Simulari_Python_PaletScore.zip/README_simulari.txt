SIMULĂRI PYTHON PALETSCORE
20 noiembrie 2026

Conținut
simulari_python.py: codul complet și ipotezele analizei.
python_debit_schimb.csv: 72 de combinații de debit, format și schimbare.
python_separatoare.csv: 6 cazuri cu pauze intermediare.
python_buffer.csv: 8 cazuri cu alimentare regulată sau în valuri.
python_comercial_*.csv: câte 10.000 de rulări pentru fiecare din 4 variante.
rezultate_python.json: parametri, rezultate agregate și verificări.
assets/python_*.png: graficele folosite în document.

Rulare
Python 3.10 sau mai nou, cu NumPy și Pillow instalate.
Din directorul în care ai dezarhivat pachetul:
python3 simulari_python.py
Rularea recreează rezultatele și graficele în același director.
Sămânța aleatoare este fixată la 20261120.

Proveniență și limite
Reperele de 5 și 13 kg, 100 și 44 găleți/palet și 8,6 și 7,4 găleți/min
provin din cerințele SYSUP 2026 furnizate pentru concurs.
Nu am primit serii temporale măsurate în fabrici. Timpii variabili, pauzele
de separator, conversiile, repartizarea cererilor și ciclul de vânzare sunt
ipoteze explicite, nu un set de date industriale observate.

Modelul Python este independent de motorul aplicației publice.
Folosește timp continuu și poate diferi cu o găleată față de discretizarea
de 0,1 s. Diferențele sunt explicate în document.

La buffer plin, o sosire planificată este numărată ca reținută în amonte.
Nu este reintrodusă ulterior în aceeași oră. Nu este declarată rebut.
Conservarea fluxului este verificată în fiecare rulare.
Pauza de separator este o întârziere abstractă. Nu simulează accesul sigur,
scannerul, traiectoriile robotului sau alocarea operatorului la separator.

Cele patru variante comerciale folosesc aceleași numere aleatoare.
Se modifică durata vânzării, termenul de livrare sau capacitatea, potrivit
etichetei. Procentele sunt ponderi ale rulărilor sub aceste ipoteze, nu
probabilități de succes estimate din piață.
Profitul folosește 130.000 EUR preț, 110.000 EUR cost direct, 30.000 EUR
promovare, 50.000 EUR alte costuri și impozit ipotetic de 16% pe rezultat
pozitiv. Nu este un model de numerar sau o verificare fiscală.

Aplicația: https://razvanalecse.github.io/paletscore/
Codul aplicației: https://github.com/razvanalecse/paletscore
