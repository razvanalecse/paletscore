"""Analize reproductibile PaletScore. Python 3, NumPy și Pillow.

Date de referință: 13 kg, 44 găleți/palet, 7,4/min; 5 kg, 100/palet,
8,6/min. Restul parametrilor sunt ipoteze, nu observații din fabrici.
Model independent, cu evenimente continue. Nu reproduce discretizarea 0,1 s
a aplicației Claude. Nu proiectează configurația de siguranță.
"""
from pathlib import Path
import csv, heapq, json, math
import numpy as np
from PIL import Image, ImageDraw, ImageFont

ROOT=Path(__file__).parent; A=ROOT/'assets';A.mkdir(exist_ok=True)
RNG=np.random.default_rng(20261120)
REF={13:(44,7.4,11),5:(100,8.6,20)}

def simulate(kg=13,feed=7.4,change=90,buffer=None,burst=False,
             separator=0,variable=False,jitter=False,seed=1,horizon=3600):
    rng=np.random.default_rng(seed);per,cap,layer=REF[kg];cycle=60/cap
    # Prioritate la egalitate: eliberare palet, finalizare ciclu, sosire.
    events=[];t=0;interval=60/feed
    if burst:
        # Aceleași sosiri totale ca la alimentarea regulată. Ceasul activ
        # este comprimat de trei ori în ferestrele de 40 s din fiecare 120 s.
        for j in range(1,int((horizon+1e-8)/interval)+1):
            u=j*interval/3;block=math.floor((u-1e-9)/40)
            tt=block*120+(u-block*40)
            heapq.heappush(events,(tt,2,-1))
    else:
        while True:
            if jitter:
                sigma=math.sqrt(math.log(1+.15**2));delta=rng.lognormal(math.log(interval)-sigma*sigma/2,sigma)
            else:delta=interval
            t+=delta
            if t>horizon+1e-8:break
            heapq.heappush(events,(t,2,-1))
    offered=len(events)
    pallets=[0,0];ready=[True,True];active=0;queue=0;busy=False
    placed=held=maxq=0;op_free=0;available=0;wait=0;last=0
    while events:
        t,kind,idx=heapq.heappop(events)
        if t>horizon+1e-8:break
        if not busy and queue and not any(ready):wait+=t-last
        last=t
        if kind==0:ready[idx]=True;pallets[idx]=0
        elif kind==1:
            busy=False;placed+=1;pallets[idx]+=1
            if pallets[idx]==per:
                ready[idx]=False
                duration=float(rng.triangular(60,180,420)) if variable else change
                op_free=max(t,op_free)+duration
                heapq.heappush(events,(op_free,0,idx))
                active=1-idx
            elif separator and pallets[idx]%layer==0:
                available=t+separator
                heapq.heappush(events,(available,3,-1))
        elif kind==2:
            if buffer is not None and queue>=buffer:held+=1
            else:queue+=1;maxq=max(maxq,queue)
        if not busy and queue and t>=available-1e-8:
            if not ready[active] and ready[1-active]:active=1-active
            if ready[active]:
                busy=True;queue-=1;heapq.heappush(events,(t+cycle,1,active))
    if not busy and queue and not any(ready):wait+=horizon-last
    assert offered==placed+queue+held+int(busy), 'Conservarea fluxului'
    return {'paletizate':placed,'coada_finala':queue,'coada_maxima':maxq,
            'retinute_amonte':held,'asteptare_pozitie_s':round(wait,3),
            'sosiri_planificate':offered,'in_ciclu_la_final':int(busy)}

def quant(x):
    return {'p10':float(np.percentile(x,10)),'mediana':float(np.median(x)),
            'p90':float(np.percentile(x,90)),'medie':float(np.mean(x))}

grid=[]
for kg in [13,5]:
    for feed in [4,5,6,7,7.4,8,8.6,10,11]:
        for change in [90,240,420,600]:
            grid.append({'kg':kg,'intrare_min':feed,'schimb_s':change,**simulate(kg,feed,change)})

separators=[]
for kg in [13,5]:
    for pause in [0,10,20]:
        separators.append({'kg':kg,'separator_s':pause,**simulate(kg,REF[kg][1],90,separator=pause)})

variability={}
for kg in [13,5]:
    runs=[simulate(kg,REF[kg][1],90,variable=True,jitter=True,seed=20261120+i) for i in range(500)]
    variability[str(kg)]={'volum':quant([r['paletizate'] for r in runs]),
                         'asteptare':quant([r['asteptare_pozitie_s'] for r in runs]),
                         'cu_blocaj':sum(r['asteptare_pozitie_s']>0 for r in runs)/len(runs)}

buffers=[]
for burst in [False,True]:
    for buffer in [5,10,20,None]:
        buffers.append({'alimentare':'valuri' if burst else 'regulata','buffer':buffer,
                        **simulate(13,7.4,90,buffer=buffer,burst=burst)})

# În fiecare lună pornim de la cereri relevante diferite, fără dubluri.
# Conversii independente condiționate: 40% la întâlnire, apoi 25% la client.
# Fiecare client câștigat cumpără două celule (ipoteza scenariului de bază).
LEADS=[30,25,20,15,10,8,6,6,0,0,0,0]
assert sum(LEADS)==120
def commercial(n=10000,sales_months=(1,2,3),sales_p=(.2,.5,.3),lead=4,capacity=4,scenario='baza'):
    rng=np.random.default_rng(20261120)
    delivered=[];ordered=[]
    for trial in range(n):
        due=np.zeros(24,dtype=int);orders=0
        for month,count in enumerate(LEADS):
            meetings=rng.binomial(count,.4);wins=rng.binomial(meetings,.25)
            for _ in range(wins):
                # Aceleași numere aleatoare pentru comparațiile de capacitate
                # și termen, pentru ca efectul să nu vină din alt eșantion.
                u=rng.random();choice=min(int(np.searchsorted(np.cumsum(sales_p),u)),len(sales_months)-1)
                close=month+int(sales_months[choice])
                if close<12:
                    orders+=2;due[close+lead]+=2
        backlog=0;in_year=0
        for month in range(12):
            backlog+=int(due[month]);done=min(capacity,backlog);backlog-=done;in_year+=done
        delivered.append(in_year);ordered.append(orders)
    a=np.array(delivered);profit=(a*20000-80000);profit=profit-np.maximum(profit,0)*.16
    with (ROOT/f'python_comercial_{scenario}.csv').open('w',newline='',encoding='utf-8-sig') as f:
        writer=csv.writer(f);writer.writerow(['rulare','celule_comandate','celule_livrate','profit_net_eur'])
        writer.writerows((i+1,int(ordered[i]),int(a[i]),float(profit[i])) for i in range(n))
    return {'livrate':quant(a),'comandate':quant(ordered),'net':quant(profit),
            'pondere_tinta_300k':float(np.mean(profit>=300000)),
            'distributie_livrari':{str(x):int(np.sum(a==x)) for x in sorted(set(a))}}

business={'ciclu_1_3_luni':commercial(),
          'ciclu_1_luna':commercial(sales_months=(1,),sales_p=(1,),scenario='vanzare_rapida'),
          'capacitate_5':commercial(capacity=5,scenario='capacitate_5'),
          'termen_5_luni':commercial(lead=5,scenario='termen_5')}
checks={
 'flux_6_min':simulate(13,6,90),
 'flux_referinta':simulate(13,7.4,90),
 'schimb_lent':simulate(13,7.4,420),
 'zero_finalizate_inainte_primul_ciclu':simulate(13,6,90,horizon=10)['paletizate']==0,
}
assert checks['flux_6_min']['paletizate']==359
assert checks['zero_finalizate_inainte_primul_ciclu']
assert simulate(5,11,90,buffer=20)['coada_maxima']<=20
assert simulate(13,7.4,90)['paletizate']>=simulate(13,7.4,420)['paletizate']

for name,records in [('debit_schimb',grid),('separatoare',separators),('buffer',buffers)]:
    with (ROOT/f'python_{name}.csv').open('w',newline='',encoding='utf-8-sig') as f:
        writer=csv.DictWriter(f,fieldnames=records[0].keys());writer.writeheader();writer.writerows(records)
results={'samanta':20261120,'grila':grid,'separatoare':separators,'variatie':variability,
         'buffer':buffers,'comercial':business,'verificari':checks}
(ROOT/'rezultate_python.json').write_text(json.dumps(results,ensure_ascii=False,indent=2))

# Grafice generate din rezultate. Intervalele din simulări nu sunt intervale
# de încredere estimate pe un eșantion de fabrici.
FONT='/System/Library/Fonts/Supplemental/Arial.ttf'
def font(n=25):
    for name in [FONT,'DejaVuSans.ttf','Arial.ttf']:
        try:return ImageFont.truetype(name,n)
        except OSError:pass
    return ImageFont.load_default(size=n)
def txt(d,xy,t,n=25,fill='#253746',anchor='mm'):
    d.multiline_text(xy,t,font=font(n),fill=fill,anchor=anchor,align='center',spacing=8)
def canvas(h):
    im=Image.new('RGB',(1800,h),'white');return im,ImageDraw.Draw(im)

im,d=canvas(850)
for k,kg in enumerate([13,5]):
    x0=160+k*850;y0=140;cw=150;ch=63
    txt(d,(x0+300,40),f'Format {kg} kg',32)
    for j,change in enumerate([90,240,420,600]):txt(d,(x0+j*cw+cw/2,100),f'{change} s',25)
    for i,feed in enumerate([4,5,6,7,7.4,8,8.6,10,11]):
        txt(d,(x0-20,y0+i*ch+ch/2),str(feed).replace('.',','),24,anchor='rm')
        for j,change in enumerate([90,240,420,600]):
            r=next(r for r in grid if r['kg']==kg and r['intrare_min']==feed and r['schimb_s']==change)
            loss=1-r['paletizate']/min(feed,REF[kg][1])/60
            col='#DCE8F0' if loss<.015 else '#F4DCCB' if loss>.08 else '#ECE9DA'
            d.rectangle((x0+j*cw,y0+i*ch,x0+(j+1)*cw-3,y0+(i+1)*ch-3),fill=col)
            txt(d,(x0+j*cw+cw/2,y0+i*ch+ch/2),str(r['paletizate']),27)
txt(d,(900,760),'Coloane: schimbare palet. Rânduri: alimentare în găleți/min.',27)
txt(d,(900,810),'Celule: găleți finalizate în prima oră. Albastru: abatere mică față de limita nominală.',24)
im.save(A/'python_harta.png')

im,d=canvas(600);left,right,top,bottom=150,1690,70,450
for v in range(0,601,100):
    y=bottom-v/600*(bottom-top);d.line([(left,y),(right,y)],fill='#E0E5E8',width=2);txt(d,(left-18,y),str(v),24,anchor='rm')
for i,r in enumerate(separators):
    x=left+135+i*245;y=bottom-r['paletizate']/600*(bottom-top)
    d.rectangle((x-65,y,x+65,bottom),fill='#52718A' if r['kg']==13 else '#253746')
    txt(d,(x,y-25),str(r['paletizate']),28)
    txt(d,(x,500),f"{r['kg']} kg\n{r['separator_s']} s",25)
txt(d,(left,25),'Găleți finalizate în 60 minute',27,anchor='lm')
txt(d,(900,575),'Pauză ipotetică la separator după fiecare strat intermediar',26)
im.save(A/'python_separatoare.png')

im,d=canvas(630);left,right,top,bottom=150,1710,60,470
hist=business['ciclu_1_3_luni']['distributie_livrari'];xs=list(range(0,33));maxcount=max(hist.values())/100
for yv in range(0,int(math.ceil(maxcount/5))*5+1,5):
    y=bottom-yv/(maxcount*1.15)*(bottom-top);d.line([(left,y),(right,y)],fill='#E0E5E8',width=2);txt(d,(left-20,y),f'{yv}%',23,anchor='rm')
for x in xs:
    count=hist.get(str(x),0)/100;xx=left+x/33*(right-left);y=bottom-count/(maxcount*1.15)*(bottom-top)
    d.rectangle((xx,y,xx+35,bottom),fill='#BD642B' if x<22 else '#52718A')
    if x%2==0:txt(d,(xx+17,bottom+30),str(x),24)
txt(d,(150,22),'Pondere din cele 10.000 de rulări',27,anchor='lm')
txt(d,(900,555),'Celule livrate în an',28)
txt(d,(900,605),'Albastru: cel puțin 22 de celule. Parametrii comerciali sunt ipoteze.',25)
im.save(A/'python_comercial.png')

im,d=canvas(720);txt(d,(900,50),'Sensibilitatea țintei la timp și capacitate',32)
for i,(key,label) in enumerate([('ciclu_1_3_luni','Vânzare 1–3 luni, livrare 4 luni, 4 celule/lună'),('ciclu_1_luna','Vânzare 1 lună, livrare 4 luni, 4 celule/lună'),('capacitate_5','Vânzare 1–3 luni, livrare 4 luni, 5 celule/lună'),('termen_5_luni','Vânzare 1–3 luni, livrare 5 luni, 4 celule/lună')]):
    y=180+i*130;p=business[key]['pondere_tinta_300k'];txt(d,(70,y-40),label,26,anchor='lm')
    d.rectangle((70,y,1630,y+35),fill='#EDF1F4');d.rectangle((70,y,70+1560*p,y+35),fill='#52718A')
    txt(d,(1670,y+17),f'{p:.1%}',27)
txt(d,(900,700),'Ponderea rulărilor cu minimum 300.000 EUR net. Nu este o probabilitate de piață.',24)
im.save(A/'python_sensibilitate.png')

print(json.dumps({'variatie':variability,'separatoare':separators,'comercial':{k:{a:b for a,b in v.items() if a!='distributie_livrari'} for k,v in business.items()},'verificari':checks},ensure_ascii=False,indent=2))
